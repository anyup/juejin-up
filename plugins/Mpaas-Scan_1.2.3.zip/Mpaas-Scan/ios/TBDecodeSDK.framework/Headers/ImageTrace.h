//
//  ImageTrace.h
//  TBDecodeSDK
//
//  Created by yinhai.tyh on 2020/10/15.
//  Copyright © 2020 Alipay. All rights reserved.
//

#ifndef ImageTrace_h
#define ImageTrace_h


@interface APImageTrace : NSObject

+ (BOOL)checkIfSystemFreeSizeIsEnoughForImageTrace;

+ (BOOL)isTraceImageOn;

+ (void)setConfig;

+ (bool)pushTraceImage:(NSData *)imageData;

@end


#endif /* ImageTrace_h */
