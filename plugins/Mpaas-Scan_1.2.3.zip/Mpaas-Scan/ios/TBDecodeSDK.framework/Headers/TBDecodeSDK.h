//
//  TBDecodeSDK.h
//  TBDecodeSDK
//
//  Created by 子泰 on 15/10/22.
//  Copyright (c) 2015年 xiami. All rights reserved.
//

#import <TBDecodeSDK/tbItf.h>

#ifndef ALIPAY_DEPRECATED
#import <TBDecodeSDK/QRCodeEncoder.h>
#endif

#import <TBDecodeSDK/TBDecoder.h>
#import <TBDecodeSDK/TBDecodeResult.h>
#import <TBDecodeSDK/TBDecodeiOSDefine.h>
