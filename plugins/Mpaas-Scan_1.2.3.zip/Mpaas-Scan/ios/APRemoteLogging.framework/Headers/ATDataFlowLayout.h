//
//  ATDataFlowLayout.h
//  APRemoteLogging
//
//  Created by 卡迩 on 2018/7/2.
//  Copyright © 2018年 Alipay. All rights reserved.
//

#import "ATLayout.h"

extern NSString *const kDefaultDataFlowHeader; /**< 默认流量监控埋点Header: DF*/

/**
 * 流量监控埋点Layout
 */
@interface ATDataFlowLayout : ATLayout

@end
