//
//  APRemoteMarco.h
//  APRemoteLogging
//
//  Created by LiMengtian on 2018/8/28.
//  Copyright © 2018年 Alipay. All rights reserved.
//

/*
 Export Marco:
 
 LOG_SDK_LEVEL
 SDK_IS4_ALIPAY
 SDK_IS4_TAOBAO

 */

#ifndef APRemoteMarco_h
#define APRemoteMarco_h

#define SDK_IS4_ALIPAY


//#ifndef SDK_LEVEL
//#define SDK_LEVEL LOG_SDK_4AP
//#endif
//
//
///** SDK LEVEL*/
//#define LOG_SDK_4AP 1   //输出支付宝
//#define LOG_SDK_4TB 0    //输出淘宝
//
//
//#ifdef SDK_LEVEL
//    #define LOG_SDK_LEVEL SDK_LEVEL
//#else
//    #define LOG_SDK_LEVEL LOG_SDK_4AP
//#endif
//
//
//#if (LOG_SDK_LEVEL == LOG_SDK_4AP)
//    #define SDK_IS4_ALIPAY
//#elif (LOG_SDK_LEVEL == LOG_SDK_4TB)
//    #define SDK_IS4_TAOBAO
//#endif


#endif /* APRemoteMarco_h */
