//
//  FullScreenScanViewController.h
//  alipayScanSDKDemo
//
//  Created by zikong on 2021/7/12.
//  Copyright © 2021 satyso. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TBScanSDK/TBScanSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FullScreenScanViewController : TBScanViewController <TBScanViewControllerDelegate>

- (instancetype)initWithCallback:(MPModuleKeepAliveCallback)callback;

- (instancetype)initWithAnimationRect:(CGRect)animationRect delegate:(id<TBScanViewControllerDelegate>)delegate;

@end

NS_ASSUME_NONNULL_END
